# AI SOC: Network Attack Detection & Visual Investigation

Flow-based attack detection with per-alert explanations (TreeSHAP), MITRE ATT&CK mapping, incident grouping,
and a visual investigation dashboard (connection graph + timeline + replay).

## Run
```bash
pip install -r requirements.txt
python -m src.generate_data   # synthetic flows -> data/flows.csv (or put real flows there)
python -m src.train           # LightGBM + RandomForest + IsolationForest, chronological split
python -m src.detect          # alerts, SHAP reasons, MITRE, incidents -> data/alerts.csv
streamlit run app/dashboard.py
```

## Dashboard (5 tabs)
- **Command center**: live threat-level gauge, KPIs (incl. alert-to-incident reduction), alert volume over time with replay marker, severity mix,
  Sankey (attack type -> targeted service -> severity), live incident feed, noisiest sources, attack heatmap.
- **Incident queue**: risk-scored incidents (severity + volume + confidence), editable status workflow (New / Investigating / Contained / False positive / Resolved).
- **Investigation**: connection graph, TreeSHAP "why flagged", response playbook checklist, analyst notes, downloadable incident report (.md).
- **ATT&CK & intel**: MITRE ATT&CK matrix, attack-stage timeline, most-targeted services, blocklist/IOC export (.csv).
- **Model quality**: per-class P/R/F1, confusion matrix, end-to-end pipeline vs ground truth.
SOC logic lives in `src/soc.py` (no UI dependency).

## Pipeline
flows -> `preprocess.py` (clean + behavioral window features) -> `train.py` (time split, per-class metrics, FPR)
-> `detect.py` (classifier + anomaly layer, TreeSHAP, severity, incidents) -> `app/dashboard.py`

## Using real data (CIC-IDS2017)
Create `data/flows.csv` with columns: `ts, src, dst, dport, duration, fwd_pkts, bwd_pkts, fwd_bytes, bwd_bytes,
syn_count, rst_count, label` (map CICFlowMeter columns; `ts` in seconds, `label` = Benign/attack name).
Add the other CIC features to `FEATURES` in `src/preprocess.py` if wanted. Clean `inf`/NaN (handled in `clean()`).

## Design choices
- Chronological train/test split (no random split -> no leakage between attack sessions).
- IPs, ports, timestamps excluded from features; host-behavior window aggregates used instead.
- Anomaly layer (IsolationForest on benign) flags traffic no class explains.
- Replay: dashboard sidebar slider re-plays alerts up to a chosen moment.

## Known limitations
- Bundled data is synthetic and easy; scores are optimistic. Evaluate on real data before drawing conclusions.
- Windowed features need the full flow set; a live version needs streaming aggregation.
