import json, sys, pathlib, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import numpy as np, pandas as pd, plotly.express as px, plotly.graph_objects as go, streamlit as st
import streamlit.components.v1 as components
import plotly.io as pio
from pyvis.network import Network
from src.soc import (SEV_RANK, STATUSES, TACTICS, KILL_CHAIN, PLAYBOOKS, build_incidents, threat_level,
                     attack_coverage, blocklist, incident_report, fmt_t)

st.set_page_config(page_title="AI SOC", layout="wide", page_icon="🛡️")

SEV_COLOR = {"Critical": "#e24b4a", "High": "#ef9f27", "Medium": "#378add", "Low": "#888780"}
ATK_COLOR = {"DDoS": "#e24b4a", "BruteForce": "#ef9f27", "Botnet": "#7f77dd", "PortScan": "#378add", "Anomaly": "#888780"}
LEVEL_COLOR = {"NORMAL": "#5dcaa5", "GUARDED": "#5dcaa5", "ELEVATED": "#378add", "HIGH": "#ef9f27", "CRITICAL": "#e24b4a"}
STATUS_COLOR = {"New": "#e24b4a", "Investigating": "#ef9f27", "Contained": "#378add", "False positive": "#888780", "Resolved": "#5dcaa5"}
INK, MUTED, GRID = "#e6e9ef", "#8b95a7", "rgba(255,255,255,0.07)"

pio.templates["soc"] = pio.templates["plotly_dark"]
pio.templates["soc"].layout.update(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(color=INK, size=12),
                                   xaxis=dict(gridcolor=GRID, zerolinecolor=GRID), yaxis=dict(gridcolor=GRID, zerolinecolor=GRID),
                                   margin=dict(l=10, r=10, t=44, b=10), title=dict(font=dict(size=14)),
                                   legend=dict(orientation="h", y=-0.2, x=0, font=dict(size=11)))
pio.templates.default = "soc"; px.defaults.template = "soc"

st.markdown("""<style>
.block-container{padding-top:1.2rem;max-width:1500px}
.hero{background:linear-gradient(120deg,#131a26 0%,#1a2236 60%,#2a1a24 100%);border:1px solid #232d3f;border-radius:14px;padding:16px 22px;margin-bottom:14px}
.hero h1{margin:0;font-size:26px}.hero p{margin:2px 0 0;color:#8b95a7;font-size:13px}
.kpi{background:#131a26;border:1px solid #232d3f;border-left:4px solid var(--c);border-radius:10px;padding:12px 16px;height:100%}
.kpi .l{font-size:11px;color:#8b95a7;text-transform:uppercase;letter-spacing:.07em}
.kpi .v{font-size:27px;font-weight:650;margin-top:2px;line-height:1.15}
.kpi .s{font-size:11px;color:#8b95a7;margin-top:2px}
.badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;margin-right:6px;color:#fff}
.legend span{display:inline-block;margin-right:14px;font-size:12px;color:#aab3c2}
.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}
.reason{background:#131a26;border:1px solid #232d3f;border-radius:10px;padding:12px 14px;margin:8px 0}
.feed{background:#131a26;border:1px solid #232d3f;border-left:3px solid var(--c);border-radius:8px;padding:8px 12px;margin-bottom:7px;font-size:12.5px}
.feed b{font-size:13px}.feed .t{color:#8b95a7;font-size:11px;float:right}
.matrix{display:grid;grid-template-columns:repeat(14,minmax(0,1fr));gap:6px}
.mcol .h{font-size:10.5px;color:#8b95a7;text-align:center;padding:6px 2px;border-bottom:2px solid #232d3f;margin-bottom:6px;min-height:34px}
.mcol.on .h{color:#e6e9ef;border-bottom-color:#e24b4a;font-weight:600}
.cell{background:rgba(226,75,74,var(--a));border:1px solid #e24b4a;border-radius:6px;padding:6px;font-size:11px;margin-bottom:5px}
.cell b{display:block;font-size:14px}
.pill{display:inline-block;padding:1px 9px;border-radius:999px;font-size:11px;font-weight:600;color:#fff}
</style>""", unsafe_allow_html=True)


def kpi(label, value, color="#378add", sub=""):
    return f'<div class="kpi" style="--c:{color}"><div class="l">{label}</div><div class="v">{value}</div><div class="s">{sub}</div></div>'


def badge(text, color):
    return f'<span class="badge" style="background:{color}">{text}</span>'


def rgba(hex_, a):
    h = hex_.lstrip("#"); return f"rgba({int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)},{a})"


def sev_style(v):
    return f"background-color:{SEV_COLOR.get(v, '#444')}33;color:{SEV_COLOR.get(v, '#ccc')};font-weight:600"


def style_sev(df):
    f = df.style.map if hasattr(df.style, "map") else df.style.applymap
    return f(sev_style, subset=["severity"])


@st.cache_data
def load():
    # keep_default_na=False so the literal mitre_id "N/A" is not turned into NaN
    a = pd.read_csv("data/alerts.csv", keep_default_na=False, na_values=[])
    f = pd.read_csv("data/flows_test.csv", keep_default_na=False, na_values=[])
    return a, f, json.load(open("models/metrics.json"))


alerts, flows, metrics = load()
t_min, t_max = float(flows.ts.min()), float(flows.ts.max())

# ---- Sidebar: replay, filters, analyst
with st.sidebar:
    st.header("🎞️ Replay")
    if "t_next" in st.session_state: st.session_state["t"] = st.session_state.pop("t_next")
    play = st.toggle("▶ Auto-play replay", value=False)
    t_now = st.slider("Replay time", t_min, t_max, t_max, step=10.0, key="t", format="%.0f s")
    st.progress((t_now - t_min) / (t_max - t_min), text=f"{fmt_t(t_now - t_min)} / {fmt_t(t_max - t_min)}")
    st.header("🔎 Filters")
    sev = st.multiselect("Severity", list(SEV_COLOR), default=list(SEV_COLOR))
    atk = st.multiselect("Attack type", list(ATK_COLOR), default=list(ATK_COLOR))
    min_conf = st.slider("Min. confidence", 0.0, 1.0, 0.0, 0.05)
    st.header("👤 Analyst")
    analyst = st.text_input("Name", value="Tier-1 analyst")

view = alerts[(alerts.ts <= t_now) & alerts.severity.isin(sev) & alerts.attack.isin(atk) & (alerts.confidence >= min_conf)]
inc = build_incidents(view)
score, level = threat_level(alerts, t_now)
lc = LEVEL_COLOR[level]

if "status" not in st.session_state: st.session_state["status"] = {}
if "notes" not in st.session_state: st.session_state["notes"] = {}
status = st.session_state["status"]

# ---- Hero
st.markdown(f'<div class="hero"><h1>🛡️ AI SOC — Detection, Triage & Visual Investigation</h1>'
            f'<p>Flow-based ML detection · TreeSHAP explanations · MITRE ATT&CK mapping · incident triage · response playbooks &nbsp;|&nbsp; '
            f'Replay clock <b style="color:#e6e9ef">{fmt_t(t_now - t_min)}</b></p></div>', unsafe_allow_html=True)

tab1, tab2, tab3, tab4, tab5 = st.tabs(["🚨 Command center", "📋 Incident queue", "🕸️ Investigation", "🎯 ATT&CK & intel", "📈 Model quality"])

# =============================================================== Command center
with tab1:
    g, *k = st.columns([1.5, 1, 1, 1.2, 1, 1])
    with g:
        fig = go.Figure(go.Indicator(mode="gauge+number", value=score, number=dict(font=dict(size=34, color=lc)),
                                     title=dict(text=f"THREAT LEVEL · <b style='color:{lc}'>{level}</b>", font=dict(size=13)),
                                     gauge=dict(axis=dict(range=[0, 100], tickcolor=MUTED), bar=dict(color=lc, thickness=0.28), bgcolor="rgba(0,0,0,0)",
                                                borderwidth=0, steps=[dict(range=[0, 15], color="rgba(93,202,165,.18)"), dict(range=[15, 40], color="rgba(55,138,221,.18)"),
                                                                      dict(range=[40, 70], color="rgba(239,159,39,.18)"), dict(range=[70, 100], color="rgba(226,75,74,.22)")])))
        fig.update_layout(height=190, margin=dict(l=20, r=20, t=40, b=0))
        st.plotly_chart(fig, width="stretch")
    n_al, n_inc = len(view), len(inc)
    red = (1 - n_inc / n_al) * 100 if n_al else 0
    open_inc = int((~inc.incident.map(lambda i: status.get(i, "New")).isin(["Resolved", "False positive", "Contained"])).sum()) if n_inc else 0
    k[0].markdown(kpi("Alerts", f"{n_al:,}", "#378add", "raw detections"), unsafe_allow_html=True)
    k[1].markdown(kpi("Incidents", n_inc, "#7f77dd", f"{red:.1f}% fewer to triage"), unsafe_allow_html=True)
    k[2].markdown(kpi("Open incidents", open_inc, "#ef9f27", "not yet contained"), unsafe_allow_html=True)
    k[3].markdown(kpi("Critical / High", int(inc.severity.isin(["Critical", "High"]).sum()) if n_inc else 0, "#e24b4a", "incidents"), unsafe_allow_html=True)
    k[4].markdown(kpi("Attacker IPs", view[view.attack != "Anomaly"].src.nunique(), "#d4537e", "unique sources"), unsafe_allow_html=True)
    st.write("")

    if view.empty:
        st.info("No alerts for the current filters / replay time.")
    else:
        c1, c2 = st.columns([3, 1.4])
        with c1:
            b = view.assign(t=(view.ts // 15 * 15)).pivot_table(index="t", columns="attack", values="ts", aggfunc="size", fill_value=0)
            b = b.reindex(np.arange(b.index.min(), b.index.max() + 15, 15), fill_value=0)
            fig = go.Figure()
            for a_ in b.columns:
                fig.add_trace(go.Scatter(x=b.index, y=b[a_], name=a_, mode="lines", stackgroup="one", line=dict(width=1, color=ATK_COLOR[a_]),
                                         fillcolor=rgba(ATK_COLOR[a_], .55), hovertemplate="%{y} alerts<extra>" + a_ + "</extra>"))
            fig.add_vline(x=t_now, line=dict(color="#e6e9ef", dash="dot", width=1))
            fig.update_layout(title="Alert volume over time (15 s bins)", height=300, xaxis_title="replay time (s)", yaxis_title="alerts")
            st.plotly_chart(fig, width="stretch")
        with c2:
            s = view.severity.value_counts().reindex(list(SEV_COLOR)).dropna()
            fig = go.Figure(go.Pie(labels=s.index, values=s.values, hole=.62, marker=dict(colors=[SEV_COLOR[x] for x in s.index]), textinfo="percent", sort=False))
            fig.update_layout(title="Severity mix", height=300, annotations=[dict(text=f"<b>{len(view):,}</b><br>alerts", x=.5, y=.5, showarrow=False, font=dict(size=14))])
            st.plotly_chart(fig, width="stretch")

        c3, c4 = st.columns([3, 1.4])
        with c3:  # Sankey: attack type -> targeted service -> severity
            sk = view.assign(target=view.dst + ":" + view.dport.astype(str))
            top_t = sk.target.value_counts().head(8).index
            sk["target"] = sk.target.where(sk.target.isin(top_t), "other targets")
            atks, tgts, sevs = sorted(sk.attack.unique()), sorted(sk.target.unique()), [s_ for s_ in SEV_COLOR if s_ in set(sk.severity)]
            labels = atks + tgts + sevs; idx = {("a", x): i for i, x in enumerate(atks)}
            idx.update({("t", x): len(atks) + i for i, x in enumerate(tgts)}); idx.update({("s", x): len(atks) + len(tgts) + i for i, x in enumerate(sevs)})
            l1 = sk.groupby(["attack", "target"]).size().reset_index(name="n"); l2 = sk.groupby(["target", "severity"]).size().reset_index(name="n")
            src_, dst_, val, col = [], [], [], []
            for _, r in l1.iterrows(): src_.append(idx[("a", r.attack)]); dst_.append(idx[("t", r.target)]); val.append(r.n); col.append(rgba(ATK_COLOR[r.attack], .35))
            for _, r in l2.iterrows(): src_.append(idx[("t", r.target)]); dst_.append(idx[("s", r.severity)]); val.append(r.n); col.append(rgba(SEV_COLOR[r.severity], .35))
            ncol = [ATK_COLOR[x] for x in atks] + ["#5dcaa5"] * len(tgts) + [SEV_COLOR[x] for x in sevs]
            fig = go.Figure(go.Sankey(node=dict(label=labels, color=ncol, pad=14, thickness=14, line=dict(width=0)), link=dict(source=src_, target=dst_, value=val, color=col)))
            fig.update_layout(title="Attack flow: type → targeted service → severity", height=340)
            st.plotly_chart(fig, width="stretch")
        with c4:
            st.markdown("**Live incident feed**")
            for _, r in view.sort_values("ts").groupby("incident").tail(1).sort_values("ts").tail(6).iloc[::-1].iterrows():
                st.markdown(f'<div class="feed" style="--c:{SEV_COLOR[r.severity]}"><span class="t">{fmt_t(r.ts - t_min)}</span><b>{r.incident} · {r.attack}</b><br>'
                            f'{r.src} → {r.dst}:{r.dport}<br><span style="color:#8b95a7">{r.severity} · {r.mitre_id}</span></div>', unsafe_allow_html=True)

        c5, c6 = st.columns(2)
        with c5:
            top = view.groupby(["src", "attack"]).size().reset_index(name="alerts").sort_values("alerts", ascending=False).head(10).iloc[::-1]
            fig = go.Figure(go.Bar(x=top.alerts, y=top.src, orientation="h", marker_color=[ATK_COLOR[a_] for a_ in top.attack],
                                   text=top.attack, textposition="inside", insidetextanchor="start"))
            fig.update_layout(title="Top 10 noisiest sources", height=340, xaxis_title="alerts")
            st.plotly_chart(fig, width="stretch")
        with c6:
            hm = view.assign(t=(view.ts // 60 * 60)).pivot_table(index="attack", columns="t", values="ts", aggfunc="size", fill_value=0)
            fig = go.Figure(go.Heatmap(z=np.log10(hm.values + 1), x=[fmt_t(c - t_min) for c in hm.columns], y=hm.index, customdata=hm.values,
                                       hovertemplate="%{y} @ %{x}: %{customdata} alerts<extra></extra>", colorscale=[[0, "#131a26"], [.4, "#7f2d3a"], [1, "#e24b4a"]], showscale=False))
            fig.update_layout(title="Attack activity heatmap (per minute, log scale)", height=340)
            st.plotly_chart(fig, width="stretch")

# =============================================================== Incident queue
with tab2:
    if inc.empty:
        st.info("No incidents for the current filters.")
    else:
        q = inc.assign(status=inc.incident.map(lambda i: status.get(i, "New")))
        cs = st.columns(len(STATUSES))
        for c_, s_ in zip(cs, STATUSES):
            c_.markdown(kpi(s_, int((q.status == s_).sum()), STATUS_COLOR[s_]), unsafe_allow_html=True)
        st.write("")
        only_open = st.toggle("Only incidents that need attention (New / Investigating)", value=False)
        qq = q[q.status.isin(["New", "Investigating"])] if only_open else q
        st.caption("Sorted by risk score (severity + volume + confidence). Change **Status** directly in the table — it is kept for this session and used in reports.")
        show = qq[["incident", "attack", "severity", "risk", "status", "alerts", "sources", "actor", "target", "dport", "start", "duration", "mitre_id", "tactic"]].copy()
        show["start"] = show.start.map(lambda t: fmt_t(t - t_min))
        edited = st.data_editor(show, hide_index=True, width="stretch", key="queue", height=min(620, 60 + 36 * len(show)),
                                disabled=[c for c in show.columns if c != "status"],
                                column_config={"risk": st.column_config.ProgressColumn("Risk", min_value=0, max_value=100, format="%d"),
                                               "status": st.column_config.SelectboxColumn("Status", options=STATUSES, required=True),
                                               "duration": st.column_config.NumberColumn("Duration (s)", format="%.0f"),
                                               "dport": st.column_config.NumberColumn("Port", format="%d")})
        for i, s_ in zip(edited.incident, edited.status): status[i] = s_
        with st.expander("Raw alerts (latest 500)"):
            st.dataframe(style_sev(view[["ts", "incident", "attack", "severity", "confidence", "src", "dst", "dport", "mitre_id", "reason"]]
                         .sort_values("ts", ascending=False).head(500)).format({"ts": "{:.0f}", "confidence": "{:.2f}"}), width="stretch", hide_index=True)


def graph_html(fl, atk_map, colors, focus=None):
    g = fl.groupby(["src", "dst"]).agg(n=("ts", "size"), attack=("attack", lambda s: next((x for x in s if x != "Benign"), "Benign"))).reset_index()
    g = g.sort_values("n", ascending=False).head(250)
    net = Network(height="520px", width="100%", directed=True, bgcolor="rgba(0,0,0,0)", cdn_resources="in_line")
    vol = pd.concat([g.groupby("src").n.sum(), g.groupby("dst").n.sum()]).groupby(level=0).sum()
    for ip, v in vol.items():
        a = atk_map.get(ip)
        net.add_node(ip, label=ip, size=10 + min(v, 400) ** .5 * 2, title=f"{ip}\n{int(v)} flows" + (f"\n{a}" if a else ""),
                     color=colors.get(a, "#5dcaa5"), borderWidth=4 if ip == focus else 1, font={"color": "#e6e9ef", "size": 12})
    for _, r in g.iterrows():
        net.add_edge(r.src, r.dst, value=float(r.n), color=colors.get(r.attack, "#b4b2a9"), title=f"{r.n} flows {r.attack}")
    net.toggle_physics(True)
    return net.generate_html()


# =============================================================== Investigation
with tab3:
    if inc.empty:
        st.info("No alerts for the current filters.")
    else:
        sel = st.selectbox("Incident (highest risk first)", inc.incident.tolist(),
                           format_func=lambda i: f"{i} — {inc.set_index('incident').loc[i, 'attack']} · risk {inc.set_index('incident').loc[i, 'risk']} · "
                                                 f"{inc.set_index('incident').loc[i, 'alerts']} alerts")
        row = inc.set_index("incident", drop=False).loc[sel]
        ia = view[view.incident == sel].sort_values("ts"); first = ia.iloc[0]
        L, R = st.columns([3, 2])
        with L:
            t0, t1 = ia.ts.min() - 60, ia.ts.max() + 60
            fl = flows[(flows.ts >= t0) & (flows.ts <= t1)]
            if first.attack == "DDoS": fl = fl[fl.dst.isin(ia.dst.unique())]
            else: fl = fl[fl.src.isin(ia.src.unique()) | fl.dst.isin(ia.src.unique())]
            amap = {}
            for _, r in ia.drop_duplicates("src").iterrows(): amap[r.src] = r.attack
            for d in ia.dst.unique(): amap.setdefault(d, "victim")
            colors = {**ATK_COLOR, "victim": "#d4537e"}
            components.html(graph_html(fl, amap, colors, focus=first.src), height=540)
            st.markdown('<div class="legend"><span><i style="background:#e24b4a"></i>DDoS</span><span><i style="background:#ef9f27"></i>BruteForce</span>'
                        '<span><i style="background:#7f77dd"></i>Botnet</span><span><i style="background:#378add"></i>PortScan</span>'
                        '<span><i style="background:#d4537e"></i>Victim</span><span><i style="background:#5dcaa5"></i>Normal host</span>'
                        '<span>· node size = traffic volume</span></div>', unsafe_allow_html=True)
        with R:
            cur = status.get(sel, "New")
            st.markdown(badge(first.attack, ATK_COLOR[first.attack]) + badge(row.severity, SEV_COLOR[row.severity]) +
                        badge(f"MITRE {first.mitre_id}", "#3a4559") + badge(row.tactic, "#3a4559") + f" {first.technique}", unsafe_allow_html=True)
            m1, m2, m3 = st.columns(3)
            m1.metric("Risk", f"{row.risk}/100"); m2.metric("Alerts", f"{row.alerts:,}"); m3.metric("Sources", row.sources)
            new = st.selectbox("Status", STATUSES, index=STATUSES.index(cur), key=f"st_{sel}")
            status[sel] = new
            st.markdown(f'<div class="reason">💡 {first.reason}</div>', unsafe_allow_html=True)
            st.caption(f"{fmt_t(row.start - t_min)} → {fmt_t(row.end - t_min)} · {row.duration:.0f}s · mean confidence {row.confidence:.2f}")
            tf = json.loads(first.top_features)
            if tf:
                d = pd.DataFrame(tf, columns=["feature", "shap", "value"]).sort_values("shap")
                fig = go.Figure(go.Bar(x=d.shap, y=d.feature, orientation="h", marker_color="#e24b4a", text=[f"= {v:,.2f}" for v in d.value], textposition="auto"))
                fig.update_layout(title="Why flagged (TreeSHAP, top features)", height=270)
                st.plotly_chart(fig, width="stretch")
            else:
                st.caption("Anomaly-layer alert: no class-specific SHAP (no known class matched).")

        P, N = st.columns([1.2, 1])
        with P:
            st.markdown("#### 🧭 Response playbook")
            for i, step in enumerate(PLAYBOOKS[first.attack]):
                st.checkbox(step, key=f"pb_{sel}_{i}")
        with N:
            st.markdown("#### 📝 Analyst notes")
            note = st.text_area("Notes", value=st.session_state["notes"].get(sel, ""), key=f"note_{sel}", label_visibility="collapsed", height=120,
                                placeholder=f"{analyst}: findings, actions taken, hand-off…")
            st.session_state["notes"][sel] = note
            st.download_button("⬇ Incident report (.md)", incident_report(row, ia, status[sel], f"{analyst}: {note}" if note else ""),
                               file_name=f"{sel}_report.md", mime="text/markdown")

        T1, T2 = st.columns(2)
        with T1:
            st.plotly_chart(px.scatter(ia.assign(t=ia.ts - t_min), x="t", y="dport", color="attack", color_discrete_map=ATK_COLOR, height=270,
                                       title="Incident timeline (time vs destination port)", labels={"t": "replay time (s)"}), width="stretch")
        with T2:
            ss = ia.src.value_counts().head(10).iloc[::-1]
            fig = go.Figure(go.Bar(x=ss.values, y=ss.index, orientation="h", marker_color=ATK_COLOR[first.attack]))
            fig.update_layout(title=f"Sources in {sel} (top 10 of {ia.src.nunique()})", height=270, xaxis_title="alerts")
            st.plotly_chart(fig, width="stretch")

# =============================================================== ATT&CK & intel
with tab4:
    cov = attack_coverage(view)
    st.markdown("#### MITRE ATT&CK matrix — techniques observed in this replay")
    cols_html, mx = [], max(cov.alerts.max(), 1) if len(cov) else 1
    for _, name in TACTICS:
        cells = cov[cov.tactic == name]
        body = "".join(f'<div class="cell" style="--a:{0.15 + 0.5 * c.alerts / mx:.2f}"><b>{c.alerts:,}</b>{c.technique}</div>' for c in cells.itertuples())
        cols_html.append(f'<div class="mcol {"on" if len(cells) else ""}"><div class="h">{name}</div>{body}</div>')
    st.markdown(f'<div class="matrix">{"".join(cols_html)}</div>', unsafe_allow_html=True)
    st.caption("Highlighted columns = tactics with detections. Counts are alerts per technique.")
    st.write("")
    a1, a2 = st.columns(2)
    with a1:
        if len(inc):
            kc = inc[inc.attack.isin(KILL_CHAIN)].assign(stage=lambda d: d.attack.map(KILL_CHAIN))
            names = {0: "Unknown", 1: "Recon (scan)", 2: "Credential attack", 3: "C2 / persistence", 4: "Impact (DoS)"}
            fig = go.Figure(go.Scatter(x=kc.start - t_min, y=kc.stage, mode="markers", text=kc.incident + " · " + kc.attack,
                                       marker=dict(size=np.clip(kc.risk / 3, 8, 34), color=[ATK_COLOR[a_] for a_ in kc.attack], line=dict(width=1, color="#0b0f17"), opacity=.85),
                                       hovertemplate="%{text}<br>start %{x:.0f}s<extra></extra>"))
            fig.update_yaxes(tickvals=list(names), ticktext=list(names.values()))
            fig.update_layout(title="Attack stage over time (bubble = risk)", height=330, xaxis_title="replay time (s)")
            st.plotly_chart(fig, width="stretch")
    with a2:
        if len(view):
            tg = (view.dst + ":" + view.dport.astype(str)).value_counts().head(10).iloc[::-1]
            fig = go.Figure(go.Bar(x=tg.values, y=tg.index, orientation="h", marker_color="#d4537e"))
            fig.update_layout(title="Most targeted services (host:port)", height=330, xaxis_title="alerts")
            st.plotly_chart(fig, width="stretch")
    st.markdown("#### 🚫 Threat-intel / blocklist export")
    bc = st.slider("Minimum confidence for blocklist", 0.5, 1.0, 0.9, 0.05)
    bl = blocklist(view, bc)
    st.caption(f"{len(bl)} indicators (attacker hosts + C2 servers) ready to import into a firewall or SIEM watchlist. Review before enforcing — internal hosts may need isolation rather than blocking.")
    st.dataframe(bl, width="stretch", hide_index=True, height=260,
                 column_config={"first_seen": st.column_config.NumberColumn("First seen (s)", format="%.0f"), "last_seen": st.column_config.NumberColumn("Last seen (s)", format="%.0f")})
    st.download_button("⬇ Download blocklist (.csv)", bl.to_csv(index=False), file_name="blocklist.csv", mime="text/csv")

# =============================================================== Model quality
with tab5:
    st.caption(f"Chronological split: {metrics['split']}. IPs/ports/timestamps are excluded from model features.")
    rep = pd.DataFrame(metrics["report"]).T.loc[metrics["labels"], ["precision", "recall", "f1-score", "support"]]
    q1, q2 = st.columns(2)
    with q1:
        fig = go.Figure()
        for m_, c_ in zip(["precision", "recall", "f1-score"], ["#378add", "#5dcaa5", "#ef9f27"]):
            fig.add_trace(go.Bar(x=rep.index, y=rep[m_], name=m_, marker_color=c_))
        fig.update_layout(title="Per-class precision / recall / F1", barmode="group", height=330, yaxis=dict(range=[0.9, 1.005]))
        st.plotly_chart(fig, width="stretch")
    with q2:
        cm = np.array(metrics["confusion"]); cmn = cm / cm.sum(1, keepdims=True)
        fig = go.Figure(go.Heatmap(z=cmn, x=metrics["labels"], y=metrics["labels"], text=cm, texttemplate="%{text}", colorscale=[[0, "#131a26"], [1, "#378add"]], showscale=False,
                                   hovertemplate="actual %{y} → predicted %{x}: %{text} (%{z:.1%})<extra></extra>"))
        fig.update_layout(title="Confusion matrix (test period, colour = row-normalised)", height=330, xaxis_title="Predicted", yaxis=dict(title="Actual", autorange="reversed"))
        st.plotly_chart(fig, width="stretch")
    st.dataframe(rep.style.format({"precision": "{:.3f}", "recall": "{:.3f}", "f1-score": "{:.3f}", "support": "{:.0f}"}), width="stretch")
    cmp = pd.DataFrame(metrics["comparison"]).T.rename(columns={"macro_f1": "Macro F1", "benign_fpr": "False-positive rate"})
    st.dataframe(cmp, width="stretch")
    st.markdown("#### End-to-end pipeline vs ground truth (classifier + anomaly layer)")
    ct = pd.crosstab(flows.label, flows.attack)
    fig = px.imshow(ct.div(ct.sum(axis=1), axis=0), x=ct.columns, y=ct.index, text_auto=".1%", color_continuous_scale=[[0, "#131a26"], [1, "#e24b4a"]],
                    labels=dict(x="Pipeline decision", y="True label"), height=340)
    fig.update_coloraxes(showscale=False)
    st.plotly_chart(fig, width="stretch")
    st.caption("The anomaly layer re-labels a small share of benign flows as 'Anomaly' — the false-positive cost of catching unknown threats; analysts triage these as Low severity.")
    st.warning("These results come from synthetic data, where attacks are cleanly separable. Expect lower recall (especially for Botnet and web attacks) and a higher false-positive rate on real CIC-IDS2017 traffic.")

# ---- Auto-play: advance replay clock and rerun
if play and t_now < t_max:
    time.sleep(0.6)
    st.session_state["t_next"] = min(t_max, t_now + 60)
    st.rerun()
