"""Synthetic network-flow generator (CIC-IDS style features) with 4 attack types.
Replace with real data by writing a CSV with the same columns to data/flows.csv."""
import numpy as np, pandas as pd

rng = np.random.default_rng(42)
T = 3600
INTERNAL = [f"10.0.0.{i}" for i in range(10, 60)]
SERVERS = [f"10.0.1.{i}" for i in range(1, 6)]
SITES = [f"142.250.{i}.10" for i in range(1, 21)]
EXT = lambda k: f"203.0.113.{k}"


def frame(ts, src, dst, dport, dur, fwd, bwd, fb, bb, syn, rst, label):
    n = len(ts)
    return pd.DataFrame(dict(ts=ts, src=src, dst=dst, dport=dport, duration=dur,
                             fwd_pkts=fwd, bwd_pkts=bwd, fwd_bytes=fb, bwd_bytes=bb,
                             syn_count=syn, rst_count=rst, label=[label] * n))


def benign(n=30000):
    src = rng.choice(INTERNAL, n)
    dst = np.where(rng.random(n) < .6, rng.choice(SERVERS, n), rng.choice(SITES, n))
    fwd, bwd = rng.poisson(12, n) + 1, rng.poisson(14, n) + 1
    return frame(rng.uniform(0, T, n), src, dst,
                 rng.choice([80, 443, 53, 22, 3306, 8080], n, p=[.25, .4, .2, .05, .05, .05]),
                 rng.lognormal(0, 1.2, n), fwd, bwd,
                 fwd * rng.lognormal(5.5, .6, n), bwd * rng.lognormal(6.5, .8, n),
                 np.ones(n), (rng.random(n) < .02).astype(int), "Benign")


def portscan(t0, atk, n=400, span=20):
    fwd, bwd = rng.integers(1, 3, n), rng.integers(0, 2, n)
    return frame(t0 + rng.uniform(0, span, n), atk, rng.choice(SERVERS), rng.choice(10000, n, replace=False) + 1,
                 rng.exponential(.002, n), fwd, bwd, fwd * 60, bwd * 54, np.ones(n), bwd, "PortScan")


def ddos(t0, victim, n=3000, span=30):
    fwd = rng.integers(3, 9, n)
    return frame(t0 + rng.uniform(0, span, n), rng.choice([EXT(k) for k in range(100, 250)], n), victim, 80,
                 rng.exponential(.05, n), fwd, rng.integers(0, 2, n), fwd * rng.normal(80, 10, n), 0,
                 rng.integers(3, 7, n), 0, "DDoS")


def brute(t0, atk, victim, n=300, span=150):
    fwd, bwd = rng.integers(10, 15, n), rng.integers(9, 13, n)
    return frame(t0 + rng.uniform(0, span, n), atk, victim, 22, rng.uniform(.8, 2.5, n), fwd, bwd,
                 fwd * rng.normal(110, 15, n), bwd * rng.normal(100, 15, n), 1, 0, "BruteForce")


def botnet(t0, host, c2, beats=40, period=30):
    ts = t0 + np.arange(beats) * period + rng.normal(0, 2, beats)
    fwd, bwd = rng.integers(4, 7, beats), rng.integers(3, 6, beats)
    return frame(ts, host, c2, 8080, rng.uniform(5, 15, beats), fwd, bwd,
                 fwd * rng.normal(90, 10, beats), bwd * rng.normal(80, 10, beats), 1, 0, "Botnet")


def generate():
    parts = [benign()]
    for i, t in enumerate([200, 900, 1700, 2700, 3300]): parts.append(portscan(t, EXT(10 + i)))
    for i, t in enumerate([500, 1500, 2900, 3400]): parts.append(ddos(t, SERVERS[i % 3]))
    for i, t in enumerate([350, 1100, 2000, 2800]): parts.append(brute(t, EXT(30 + i), SERVERS[3 + i % 2]))
    for i, t in enumerate([50, 1300, 2300]): parts.append(botnet(t, INTERNAL[5 + i * 7], f"198.51.100.{20 + i}"))
    return pd.concat(parts).sort_values("ts").reset_index(drop=True)


if __name__ == "__main__":
    df = generate(); df.to_csv("data/flows.csv", index=False)
    print(df.label.value_counts())
