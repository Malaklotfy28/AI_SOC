"""SOC logic (pure pandas/numpy, no UI): incident risk scoring, threat level, MITRE ATT&CK coverage,
response playbooks, blocklist/IOC export and incident reports. Used by app/dashboard.py."""
import numpy as np, pandas as pd

SEV_RANK = {"Low": 0, "Medium": 1, "High": 2, "Critical": 3}
SEV_NAME = {v: k for k, v in SEV_RANK.items()}
SEV_WEIGHT = {"Critical": 40, "High": 25, "Medium": 10, "Low": 3}

# MITRE ATT&CK (Enterprise) tactics in kill-chain order. id -> name
TACTICS = [("TA0043", "Reconnaissance"), ("TA0042", "Resource Dev."), ("TA0001", "Initial Access"), ("TA0002", "Execution"),
           ("TA0003", "Persistence"), ("TA0004", "Priv. Escalation"), ("TA0005", "Defense Evasion"), ("TA0006", "Credential Access"),
           ("TA0007", "Discovery"), ("TA0008", "Lateral Movement"), ("TA0009", "Collection"), ("TA0011", "Command & Control"),
           ("TA0010", "Exfiltration"), ("TA0040", "Impact")]
# technique id -> (tactic id, technique name)
TECHNIQUE_TACTIC = {"T1046": "TA0007", "T1110": "TA0006", "T1071": "TA0011", "T1498": "TA0040"}
KILL_CHAIN = {"PortScan": 1, "BruteForce": 2, "Botnet": 3, "DDoS": 4, "Anomaly": 0}

PLAYBOOKS = {
    "PortScan": ["Confirm the scanner is not an approved vulnerability scanner (check asset inventory / change calendar).",
                 "Rate-limit or temporarily block the source at the internal firewall.",
                 "Review which ports answered; verify exposed services are intended.",
                 "Hunt: did the same source later attempt logins (T1110) against the discovered services?"],
    "BruteForce": ["Block or throttle the source IP for the targeted service (SSH/RDP/web login).",
                   "Check authentication logs on the target for any SUCCESSFUL login from this source.",
                   "Force password reset + enable MFA on the targeted accounts; add account lockout.",
                   "Escalate to Incident Response if a successful login is found."],
    "Botnet": ["Isolate the infected host from the network (quarantine VLAN / EDR network containment).",
               "Block the C2 destination (IP/domain) at proxy and firewall; add to threat-intel blocklist.",
               "Collect memory + disk triage from the host; look for persistence (T1547, scheduled tasks).",
               "Hunt for other hosts contacting the same destination."],
    "DDoS": ["Engage upstream DDoS mitigation / ISP scrubbing; enable SYN cookies and connection rate limits.",
             "Apply ACL / geo / rate-limit rules in front of the targeted service.",
             "Scale or fail over the target service; announce the incident to service owners.",
             "Capture a sample (pcap) for post-incident analysis and attribution."],
    "Anomaly": ["Review the flow in context: is the host running a new/unusual application?",
                "Compare with the host's baseline; ask the owner about recent changes.",
                "If unexplained after review, escalate to Tier 2 or add to a watchlist.",
                "If benign, mark as false positive so the baseline can be tuned."],
}
STATUSES = ["New", "Investigating", "Contained", "False positive", "Resolved"]


def fmt_t(s):
    """seconds -> 'T+MM:SS' (replay clock)."""
    s = int(s)
    return f"T+{s // 60:02d}:{s % 60:02d}"


def build_incidents(alerts: pd.DataFrame) -> pd.DataFrame:
    """One row per incident with risk score (0-100), tactic and workload stats."""
    cols = ["incident", "attack", "severity", "risk", "alerts", "sources", "targets", "actor", "target", "dport",
            "start", "end", "duration", "mitre_id", "tactic", "confidence"]
    if alerts.empty:
        return pd.DataFrame(columns=cols)
    a = alerts.assign(sev_rank=alerts.severity.map(SEV_RANK))
    g = a.groupby("incident")
    inc = g.agg(attack=("attack", "first"), sev_rank=("sev_rank", "max"), alerts=("ts", "size"),
                sources=("src", "nunique"), targets=("dst", "nunique"), actor=("src", lambda s: s.mode()[0]),
                target=("dst", lambda s: s.mode()[0]), dport=("dport", lambda s: int(s.mode()[0])),
                start=("ts", "min"), end=("ts", "max"), mitre_id=("mitre_id", "first"),
                confidence=("confidence", "mean")).reset_index()
    inc["severity"] = inc.sev_rank.map(SEV_NAME)
    inc["duration"] = inc.end - inc.start
    # risk = severity base (0-60) + volume (0-25, log) + confidence (0-15)
    vol = np.clip(np.log10(inc.alerts.clip(lower=1)) / 4, 0, 1) * 25
    inc["risk"] = (inc.sev_rank / 3 * 60 + vol + inc.confidence * 15).round().clip(0, 100).astype(int)
    tid = inc.mitre_id.map(TECHNIQUE_TACTIC)
    names = dict(TACTICS)
    inc["tactic"] = tid.map(names).fillna("Unmapped")
    return inc[cols].sort_values(["risk", "start"], ascending=[False, True]).reset_index(drop=True)


def threat_level(alerts: pd.DataFrame, t_now: float, window: float = 120.0):
    """(score 0-100, label) from distinct incidents active in the last `window` seconds of replay time."""
    r = alerts[(alerts.ts <= t_now) & (alerts.ts > t_now - window)]
    if r.empty:
        return 0, "NORMAL"
    top = r.groupby("incident").severity.agg(lambda s: max(s, key=SEV_RANK.get))
    score = int(min(100, sum(SEV_WEIGHT[s] for s in top)))
    label = "CRITICAL" if score >= 70 else "HIGH" if score >= 40 else "ELEVATED" if score >= 15 else "GUARDED"
    return score, label


def attack_coverage(alerts: pd.DataFrame) -> pd.DataFrame:
    """Rows: tactic x observed techniques, for the ATT&CK matrix heatmap."""
    rows = []
    if len(alerts):
        obs = alerts[alerts.mitre_id != "N/A"].groupby(["mitre_id", "technique"]).size()
        for (tid, tech), n in obs.items():
            rows.append({"tactic": dict(TACTICS).get(TECHNIQUE_TACTIC.get(tid), "Unmapped"), "technique": f"{tid} {tech}", "alerts": int(n)})
    return pd.DataFrame(rows, columns=["tactic", "technique", "alerts"])


def blocklist(alerts: pd.DataFrame, min_conf: float = 0.9, kinds=("PortScan", "BruteForce", "Botnet", "DDoS")) -> pd.DataFrame:
    """IOC table of offending sources (one row per src+attack) suitable for firewall/SIEM import.
    For Botnet the C2 destination is the IOC, so both are listed."""
    a = alerts[alerts.attack.isin(kinds) & (alerts.confidence >= min_conf)]
    if a.empty:
        return pd.DataFrame(columns=["indicator", "role", "attack", "mitre_id", "alerts", "first_seen", "last_seen", "incident"])
    src = a.groupby(["src", "attack", "mitre_id"]).agg(alerts=("ts", "size"), first_seen=("ts", "min"), last_seen=("ts", "max"),
                                                        incident=("incident", "first")).reset_index().rename(columns={"src": "indicator"})
    src["role"] = "attacker/infected host"
    c2 = a[a.attack == "Botnet"].groupby(["dst", "attack", "mitre_id"]).agg(alerts=("ts", "size"), first_seen=("ts", "min"),
                                                                           last_seen=("ts", "max"), incident=("incident", "first")).reset_index().rename(columns={"dst": "indicator"})
    c2["role"] = "C2 server"
    out = pd.concat([src, c2], ignore_index=True)
    return out[["indicator", "role", "attack", "mitre_id", "alerts", "first_seen", "last_seen", "incident"]].sort_values("alerts", ascending=False)


def incident_report(row: pd.Series, ia: pd.DataFrame, status: str = "New", analyst_note: str = "") -> str:
    """Markdown incident report for hand-off / ticketing."""
    steps = "\n".join(f"{i}. {s}" for i, s in enumerate(PLAYBOOKS.get(row.attack, PLAYBOOKS["Anomaly"]), 1))
    srcs = ia.src.value_counts().head(5)
    return f"""# Incident {row.incident} — {row.attack}

| Field | Value |
|---|---|
| Severity | {row.severity} |
| Risk score | {row.risk}/100 |
| Status | {status} |
| MITRE ATT&CK | {row.mitre_id} ({row.tactic}) |
| Window | {fmt_t(row.start)} → {fmt_t(row.end)} ({row.duration:.0f}s) |
| Alerts | {row.alerts} from {row.sources} source(s) against {row.targets} target(s) |
| Main actor | {row.actor} |
| Main target | {row.target}:{row.dport} |
| Mean confidence | {row.confidence:.2f} |

## Why it was flagged
{ia.iloc[0].reason}

## Top sources
{chr(10).join(f"- {ip}: {n} alerts" for ip, n in srcs.items())}

## Recommended response
{steps}

## Analyst notes
{analyst_note or "_none_"}
"""
