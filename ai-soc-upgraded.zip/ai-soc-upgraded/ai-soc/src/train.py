import json, joblib, numpy as np, pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from src.preprocess import FEATURES, add_features, time_split

df = add_features(pd.read_csv("data/flows.csv"))
train, test = time_split(df)
classes = sorted(df.label.unique())
Xtr, ytr, Xte, yte = train[FEATURES], train.label, test[FEATURES], test.label

models = {"LightGBM": LGBMClassifier(n_estimators=200, learning_rate=.1, class_weight="balanced", verbose=-1, random_state=0),
          "RandomForest": RandomForestClassifier(200, max_depth=14, class_weight="balanced_subsample", n_jobs=-1, random_state=0)}
comparison = {}
for name, m in models.items():
    m.fit(Xtr, ytr); p = m.predict(Xte)
    rep = classification_report(yte, p, output_dict=True, zero_division=0)
    fpr = float(((p != "Benign") & (yte == "Benign")).sum() / (yte == "Benign").sum())
    comparison[name] = dict(macro_f1=rep["macro avg"]["f1-score"], benign_fpr=fpr)
    if name == "LightGBM":
        best, best_rep, cm = m, rep, confusion_matrix(yte, p, labels=classes).tolist()
        print(classification_report(yte, p, zero_division=0))

iso = IsolationForest(n_estimators=200, random_state=0).fit(Xtr[ytr == "Benign"])
thr = float(np.percentile(-iso.score_samples(Xtr[ytr == "Benign"]), 99.7))

joblib.dump(dict(model=best, iso=iso, thr=thr, classes=list(best.classes_)), "models/soc_model.joblib")
json.dump(dict(report=best_rep, confusion=cm, labels=classes, comparison=comparison,
               split=f"train ts<={train.ts.max():.0f}s / test ts>{train.ts.max():.0f}s (chronological)"),
          open("models/metrics.json", "w"), indent=1)
print(comparison)
