import numpy as np, pandas as pd

# IPs, ports and timestamps are deliberately NOT model features (avoid leakage).
FEATURES = ["duration", "fwd_pkts", "bwd_pkts", "fwd_bytes", "bwd_bytes", "syn_count", "rst_count",
            "pkt_len_mean", "bytes_per_sec", "src_flows_30s", "src_dst_ports_30s", "src_dst_ips_30s",
            "dst_flows_30s", "dst_fan_in_30s", "pair_flows_30s", "pair_flows_5m"]


def clean(df):
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    return df[(df.duration >= 0)].reset_index(drop=True)


def add_features(df):
    df = clean(df).sort_values("ts").reset_index(drop=True)
    df["w30"], df["w5m"] = (df.ts // 30).astype(int), (df.ts // 300).astype(int)
    df["bytes_per_sec"] = (df.fwd_bytes + df.bwd_bytes) / (df.duration + 1e-3)
    df["pkt_len_mean"] = (df.fwd_bytes + df.bwd_bytes) / (df.fwd_pkts + df.bwd_pkts).clip(lower=1)
    g = df.groupby(["src", "w30"])
    df["src_flows_30s"] = g["dst"].transform("size")
    df["src_dst_ports_30s"] = g["dport"].transform("nunique")
    df["src_dst_ips_30s"] = g["dst"].transform("nunique")
    g = df.groupby(["dst", "w30"])
    df["dst_flows_30s"] = g["src"].transform("size")
    df["dst_fan_in_30s"] = g["src"].transform("nunique")
    df["pair_flows_30s"] = df.groupby(["src", "dst", "w30"])["ts"].transform("size")
    df["pair_flows_5m"] = df.groupby(["src", "dst", "w5m"])["ts"].transform("size")
    return df


def time_split(df, frac=0.7):
    cut = df.ts.max() * frac  # chronological split, never random
    return df[df.ts <= cut], df[df.ts > cut]
