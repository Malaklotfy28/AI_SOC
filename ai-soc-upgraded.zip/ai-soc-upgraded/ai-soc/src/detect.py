"""Run detection on the test period, explain each alert (TreeSHAP), map to MITRE ATT&CK, group into incidents."""
import json, joblib, numpy as np, pandas as pd
from src.preprocess import FEATURES, add_features, time_split

MITRE = {"PortScan": ("T1046", "Network Service Discovery"), "DDoS": ("T1498", "Network Denial of Service"),
         "BruteForce": ("T1110", "Brute Force"), "Botnet": ("T1071", "Application Layer Protocol (C2)"),
         "Anomaly": ("N/A", "Unclassified anomaly")}
SEV = {"DDoS": 3, "BruteForce": 2, "Botnet": 2, "PortScan": 1, "Anomaly": 1}
SEV_NAME = ["Low", "Medium", "High", "Critical"]


def reason(r):
    a = r.attack
    if a == "PortScan": return f"Likely port scan: {r.src} probed {int(r.src_dst_ports_30s)} distinct ports in 30s using tiny, very short flows (~{r.duration*1000:.0f} ms)."
    if a == "DDoS": return f"Likely DDoS: {r.dst} received {int(r.dst_flows_30s)} flows from {int(r.dst_fan_in_30s)} distinct sources in 30s, with high SYN counts and almost no replies."
    if a == "BruteForce": return f"Likely brute-force: {r.src} opened {int(r.pair_flows_30s)} repeated login-sized sessions to {r.dst}:{int(r.dport)} within 30s."
    if a == "Botnet": return f"Likely botnet beaconing: {r.src} contacts {r.dst} periodically ({int(r.pair_flows_5m)} times in 5 min) with small, regular, long-lived flows."
    return f"Traffic from {r.src} deviates strongly from the benign baseline (isolation-forest score {r.anomaly_score:.2f}); no known attack class matched."


def run():
    art = joblib.load("models/soc_model.joblib")
    m, iso, thr, classes = art["model"], art["iso"], art["thr"], art["classes"]
    _, test = time_split(add_features(pd.read_csv("data/flows.csv")))
    test = test.reset_index(drop=True)
    X = test[FEATURES]
    proba = m.predict_proba(X)
    test["attack"] = [classes[i] for i in proba.argmax(1)]
    test["confidence"] = proba.max(1)
    test["anomaly_score"] = -iso.score_samples(X)
    unk = (test.attack == "Benign") & (test.anomaly_score > thr)
    test.loc[unk, "attack"] = "Anomaly"
    test.loc[unk, "confidence"] = 0.5

    alerts = test[test.attack != "Benign"].copy()
    # TreeSHAP via LightGBM native pred_contrib: one block per class, last column of each block = bias
    F = len(FEATURES)
    contrib = m.booster_.predict(alerts[FEATURES], pred_contrib=True)
    tops = []
    for i, (_, r) in enumerate(alerts.iterrows()):
        if r.attack == "Anomaly": tops.append("[]"); continue
        k = classes.index(r.attack); c = contrib[i, k * (F + 1):(k + 1) * (F + 1) - 1]
        o = np.argsort(-c)[:5]
        tops.append(json.dumps([[FEATURES[j], float(c[j]), float(r[FEATURES[j]])] for j in o]))
    alerts["top_features"] = tops
    alerts["reason"] = alerts.apply(reason, axis=1)
    alerts["mitre_id"] = alerts.attack.map(lambda a: MITRE[a][0])
    alerts["technique"] = alerts.attack.map(lambda a: MITRE[a][1])
    alerts["severity"] = [SEV_NAME[max(0, SEV[a] - int(c < .7))] for a, c in zip(alerts.attack, alerts.confidence)]

    # Incident triage: same attack + same actor (target for DDoS) within 90 s -> one incident
    alerts["gkey"] = alerts.attack + "|" + np.where(alerts.attack == "DDoS", alerts.dst, alerts.src)
    alerts = alerts.sort_values("ts")
    new = alerts.groupby("gkey").ts.diff().fillna(1e9) > 90
    alerts["seq"] = new.groupby(alerts.gkey).cumsum()
    alerts["incident"] = ["INC-%03d" % (i + 1) for i in pd.factorize(alerts.gkey + alerts.seq.astype(str))[0]]
    keep = ["ts", "src", "dst", "dport", "attack", "confidence", "severity", "mitre_id", "technique",
            "anomaly_score", "reason", "top_features", "incident", "label"]
    alerts[keep].to_csv("data/alerts.csv", index=False)
    test[["ts", "src", "dst", "dport", "attack", "label"]].to_csv("data/flows_test.csv", index=False)
    print(f"{len(alerts)} alerts in {alerts.incident.nunique()} incidents")
    print(alerts.groupby(["label", "attack"]).size())


if __name__ == "__main__":
    run()
